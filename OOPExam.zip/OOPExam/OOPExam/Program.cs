﻿namespace OOPExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Member member = new Member();
            member.MemberID = 1;
            member.Name = "Mohamed";
            member.Email = "Mohamed@gmail.com";
            ////////////////////////
            ///
            /// 
            /// 
            PremiumMember premiumMember = new PremiumMember();
            PremiumMember premiumMember1 = new PremiumMember();
            PremiumMember premiumMember2 = new PremiumMember();
            PremiumMember premiumMember3 = new PremiumMember();
            premiumMember1.PremiumMemberID = 5;
            premiumMember2.PremiumMemberID = 7;
            premiumMember3.PremiumMemberID = 8;

            /////////////////////////////
            Book book1 = new Book();
            book1.Title = "php";book1.BookID = 10;book1.Author = "Mousa";book1.ISBN = "128156";   
            Book book2 = new Book();
            book2.Title = ".NET";book2.BookID = 2; book2.Author = "Ahmed";book2.ISBN = "123356";    
            Book book3 = new Book();
            book3.Title = "Python"; book3.BookID = 3;book3.Author = "Abdo"; book3.ISBN = "1385651";
            /////////////////////////////////
            Library library = new Library();
            library.AddBook(book1);
            library.AddBook(book2);
            library.AddBook(book3);
            library.AddMember(member);
            //library.AddMember(member);
            premiumMember.AddPremiumMember(premiumMember2);
            premiumMember.AddPremiumMember(premiumMember1);
            premiumMember.AddPremiumMember(premiumMember3);
            premiumMember1.AddBook(book1);
            premiumMember2.AddBook(book2);
            premiumMember3.AddBook(book3);

            Console.WriteLine(library.BorrowBook(1,3));
            Console.WriteLine(library.BorrowBook(1,0));
            Console.WriteLine(premiumMember.BorrowBook(5,10));
            INotification notification = new Member();
            Console.WriteLine(notification.SendNotification("return")); 
            Console.WriteLine(notification.SendNotification("Borrow")); 





        }
    }
}
