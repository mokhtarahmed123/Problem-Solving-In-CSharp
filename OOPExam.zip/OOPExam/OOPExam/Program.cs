﻿namespace OOPExam;

internal class Program
{
    static void Main(string[] args)
    {
       
        Library library = new Library();

        library.AddBook(new Book { BookID = 1, Title = "PHP", Author = "Mousa", ISBN = "128156" });
        library.AddBook(new Book { BookID = 2, Title = ".NET", Author = "Ahmed", ISBN = "123356" });
        library.AddBook(new Book { BookID = 3, Title = "Python", Author = "Abdo", ISBN = "1385651" });
        Member member1 = new Member { MemberID = 1, Name = "Mohamed", Email = "Mohamed@gmail.com" };
        Member member2 = new Member { MemberID = 3, Name = "Alaa", Email = "Alaa@gmail.com" };
        Member member3 = new Member { MemberID = 7, Name = "Mai", Email = "Mai@gmail.com" };
        PremiumMember premiumMember1 = new PremiumMember { MemberID = 2, Name = "Youness", Email = "Youness@gmail.com" };
        PremiumMember premiumMember2= new PremiumMember { MemberID = 5, Name = "Magdy", Email = "Magdy@gmail.com" };
        PremiumMember premiumMember3 = new PremiumMember { MemberID = 6, Name = "Ahmed", Email = "Ahmed@gmail.com" };
        library.AddMember(member1);
        library.AddPremiumMembers(premiumMember1);
        Console.WriteLine(library.BorrowBook(1, 1)); 
        Console.WriteLine(library.BorrowBook(2, 2)); 
        Console.WriteLine(library.ReturnBook(1, 1)); 


    }
}
