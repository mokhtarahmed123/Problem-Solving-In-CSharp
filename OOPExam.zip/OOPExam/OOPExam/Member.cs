﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPExam
{
    public class Member : Library,INotification
    {
        public int MemberID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public List<Book> BorrowedBooks { get; set; } = new List<Book>();
        public string SendNotification(string message)
        {return $"You {message} the Book";}
    }
}
