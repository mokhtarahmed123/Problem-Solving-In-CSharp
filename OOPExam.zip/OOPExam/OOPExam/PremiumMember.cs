﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace OOPExam
{
    public class PremiumMember :  Member, INotification

    {

        public decimal MonthlyFee { get; } = 3;
        public double DiscountRate { get; } = 0.2;

    }


}
