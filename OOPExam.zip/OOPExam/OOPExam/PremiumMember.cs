﻿namespace OOPExam
{
    public class PremiumMember :  Library, INotification

    {
        public decimal MonthlyFee { get; } = 3;
        public double DiscountRate { get; } = 0.2;
        public int PremiumMemberID { get; set; }
        //public PremiumMember(int Premium_MemberID)
        //{

        //    PremiumMemberID = Premium_MemberID;
        //}
        public List<Book> BorrowedBooks = new List<Book>();
        List<PremiumMember> Premium_Member { get; set; } = new List<PremiumMember>();
        //public List<PremiumMember> Premium_Member { get; set; } = new List<PremiumMember>();
        public void AddPremiumMember(PremiumMember premiumMember)
        { Premium_Member.Add(premiumMember); }
        public override string BorrowBook(int PremiumMemberID, int bookId)
        {
            //Library library; 
            Book book = Books.Find(B => B.BookID == bookId);
            PremiumMember premiumMember = Premium_Member.Find(PM => PM.PremiumMemberID == PremiumMemberID);
            if (premiumMember == null) {
                return "Invalid member";
            }
            if (book == null)
                return "Invalid book.";

            if (book.IsBorrowed)
                return $"This book {bookId} is already borrowed. Try borrowing another one.";
            Premium_Member.Add(premiumMember);
            //PremiumMember.BorrowedBooks.Add(book);
            premiumMember.BorrowedBooks.Add(book);
            book.IsBorrowed = true;


            return $"You borrowed '{book.Title}'. (Premium Benefit: 20% discount on late fees)";

        }


        public string SendNotification(string message)
        {
            return $"  {message}";

        }
    }

}
