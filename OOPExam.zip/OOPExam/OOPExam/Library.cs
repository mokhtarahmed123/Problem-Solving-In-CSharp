﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace OOPExam
{
    public class Library
    {
        public int count = 0 ;
        public List<Book> Books { get; set; } = new List<Book>();
        public List<Member> Members { get; set; } = new List<Member>();
       
        public void AddBook(Book book)
        { Books.Add(book); }
        public void AddMember(Member member)
        { Members.Add(member); } 
       
        public virtual string BorrowBook(int memberId, int bookId)
        {
         

            Book book =Books.Find(b=>b.BookID ==bookId);
            
            Member member =Members.Find (M=>M.MemberID == memberId);
           // PremiumMember premiumMember = Premium_Member.Find (M=>M.PremiumMemberID == memberId);
         
            if (member == null ) {
                return "  invalid member";
            }
            if (book == null)
            {
                return "invalid Book";
            } 
            if(book.IsBorrowed == true)
            {
                return $"This book {bookId} is already borrowed. Try borrowing another one.";
            }
            
          
            member.BorrowedBooks.Add(book);
            book.IsBorrowed = true;
            count++;
            return $" You borrowed this book {bookId} ";
        }
        public string ReturnBook(int memberId, int bookId)
        {
            Book book = new Book();
            book.BookID = bookId;
            Member member = new Member();
            member.BorrowedBooks.Remove(book);

            book.IsBorrowed = false;
            count--;
            return $" this book {bookId} is returned ";
        }



    }
}
