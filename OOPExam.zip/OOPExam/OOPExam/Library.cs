﻿namespace OOPExam
{
    public class Library
    {
        public int count = 0;
        public List<Book> Books { get; set; } = new List<Book>();
        public List<Member> Members { get; set; } = new List<Member>();
        public List<PremiumMember> PremiumMembers { get; set; } = new List<PremiumMember>();

        public void AddBook(Book book)
        { Books.Add(book); }
        public void AddMember(Member member)
        { Members.Add(member); }
        public void AddPremiumMembers(PremiumMember member)
        { PremiumMembers.Add(member); }



        public virtual string BorrowBook(int memberId, int bookId)
        {


            Book book = Books.Find(b => b.BookID == bookId);

            Member member = Members.Find(M => M.MemberID == memberId);
            if (member == null)
            {
                return "  invalid member";
            }
            if (book == null)
            {
                return "invalid Book";
            }
            if (book.IsBorrowed == true)
            {
                return $"This book {bookId} is already borrowed. Try borrowing another one.";
            }

            member.BorrowedBooks.Add(book);
            book.IsBorrowed = true;
            Books.Remove(book);
            return member is PremiumMember ?
                $"You borrowed '{book.Title}'. (Premium Benefit: 20% discount on late fees)" :
                $"You borrowed '{book.Title}'."; ;
        }
        public string ReturnBook(int memberId, int bookId)
        {
            Book book = new Book();
            book.BookID = bookId;
            Member member = new Member();
            member.BorrowedBooks.Remove(book);

            book.IsBorrowed = false;
            Books.Add(book);

            return $" this book {bookId} is returned ";
        }



    }
}
